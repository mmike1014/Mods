ORBITAL EXCHANGE EDITOR
Windows desktop edition 1.8.2

Version 1.8.1 fixes a Windows focus error after saving character or currency
changes. Both windows retain the selected row after saving.

GET STARTED
1. Extract the whole ZIP to a folder on your PC. Keep the EXE and DLL together.
2. Run OrbitalExchangeEditor.exe. It opens your station inventory automatically
   when it finds one player profile. Use Open inventory to choose a different
   profile or to work on a copy.

The usual file is
%LOCALAPPDATA%\Icarus\Saved\PlayerData\<SteamID>\MetaInventory.json

EDIT YOUR INVENTORY
Select any inventory row to read its description and current stats in the
right-hand pane. Scroll for custom attributes, equipped parts, alterations
and base item stats. The Item tab updates as you edit. Add item shows the
starting values for a new copy and the quantity you have chosen.

Current item values come from the selected save entry. Base item stats use
the game's item definitions. The displayed bonuses retain their individual
sources. Combat totals depend on the character, ammunition, target and
conditions in game. Custom rows can show saved properties even when their
base definition is unavailable. Twenty catalog rows without authored text
have short descriptions based on their item names and game-data tags.

Use Add item to search by display name or game ID and pick a stack quantity.
The initial list shows items tagged for orbit. Include planet items also shows
ordinary materials, crafted equipment and other entries from the base game.
New items receive their own instance ID and available base template properties.
The catalog contains 3,040 item rows from Steam client build 26636089.
Stack limits and initial durability come from that build's base tables.

Choose Add-ons only to browse loose attachment kits and suit modules. To add
a modded item, enter its exact row name in Search and choose Add by game ID.
The corresponding game or mod must define that item for Icarus to load it.

Double-click an inventory row to edit it. Apply stages all changes to that item.
Cancel discards them. Save changes in the main window writes them to disk.

SAVING WHILE ICARUS IS RUNNING
Save changes works while Icarus is open. The editor combines your edits with
changes to other entries already saved on disk. If both versions changed the
same item, the editor reports the conflict and keeps your edits open. If Icarus
briefly locks the file, the editor retries. Retry Save changes if the file
remains busy.

Icarus may keep its own copy of the inventory in memory. If the Workshop
still shows older items after you save, reload Icarus. A later in-game save
can overwrite edits made on disk. The editor's status reflects the disk save.

ADD-ON EFFECTS
Select an inventory item and click Edit add-on effects. Search by the
add-on's name, game ID or description. Apply add-on effect saves the kit's
preset alteration. To change a known kit effect on the selected item, select
it on the left and a replacement on the right, then click Replace selected.
Remove selected removes just the highlighted copy.

Edit item bonuses lets you select a supported numeric stat and change its
amount. The dialog shows its default and formats your new amount as you type.
This writes a custom item attribute. An applied kit preset remains active
until you remove it. Use Attributes to review or remove the saved bonus.
Add-ons that require special game behavior are described in the catalog.
Use Add item to place a loose kit or module in the station inventory.

COMBINE MODULE EFFECTS
Open a known suit module for editing in station inventory. Click Combine
module effects. Pick a source module, select one or more effects, and click
Add selected effects. Repeat with other source modules. Use Ctrl-click to
select separate rows. Edit amount changes a selected effect's game value.
Each stat has one value in the export. Adding the same effect again keeps
the amount already selected.

Export mod creates an EXMODZ for Icarus Mod Manager. Import it alongside
your other mods, rebuild your merged PAK, and restart Icarus. The export
patches the selected module type's equipped stats, so it applies to every
copy of that module. Other stat keys are left to the game and your existing
mods. The editor previews base-game values. For a stat shared with another
mod, check which mod wins that key in your merge. The export is independent
of Save changes.

EDIT PETS AND MOUNTS
Click Edit pets at the top of the main window. The editor opens Mounts.json beside the
station inventory when available. To switch profiles, click Open Mounts.json.
Select a pet and click Edit selected pet. Stats and phenotype lets you choose
its appearance and lineage, change current health, stamina, food, water,
oxygen, XP and gestation progress, and adjust the seven genetic stats.

Vigor affects maximum health, Fitness affects maximum stamina, and Physique
affects melee damage and carry capacity. Genetic scores and perk ranks feed
the game's formulas for final stats. When an appearance is only shown as a
phenotype index, its valid range depends on the species or installed mod.

The numbered appearance list identifies 103 variants across 13 species using
the game's named colorways and pattern IDs. Select an appearance to see its
rarity and its share of the normal game's selection weights. Those percentages
describe the base pool. Breeding, talents, forced evolution and special
selection rules can change the odds. Variants outside the normal pool are
marked. Colorways named only by a pattern ID retain that ID in the label.

The Perks tab shows your pet's perk tree and any additional saved perks.
Select a perk to preview its description and rank bonuses. Set a rank to 0
to remove it, or use Max all perks to set the known perks to their highest
rank. Icarus controls in-game perk applicability and stat limits.

Click Apply pet edits, then Save pet changes. The editor makes a dated backup
beside Mounts.json. If Mounts.json has changed since opening, your pending edits
stay in the editor and the file is left intact. Close Icarus before editing pets
so it can load the edits from disk when restarted.

EDIT CURRENCY
Click Edit currency at the top of the main window. The editor reads Profile.json
beside the open station inventory, or you can choose a profile with Open
Profile.json. Select a currency and change its balance. The list includes Ren,
Exotics, Red Exotics, Uranium Rods, Legendary Biomass, Legendary Licences,
Respec Points, and Flux. Saving a positive amount adds a known currency if it
is missing. Other saved currency IDs also appear. Flux has a save ID in the
game data and may have no in-game spending use.

Click Save currency changes to write the balances and make a backup. These are
orbital profile balances. Resource stacks use the inventory editor.

EDIT CHARACTERS
Click Edit characters, then select a character and click Edit selected
character. Change the name, XP or XP debt on the Character tab. The Appearance
tab shows the stored customization indices. The game derives level from XP.
The Talents and blueprints tab lets you search by name, description or game ID
and filter by tree. Select an entry to see the description, bonuses for every
rank and prerequisites. Change the selected rank, or use 0 to clear a saved
rank. Icarus applies any default unlocks and gameplay requirements.

Click Apply character edits, then Save character changes to write
Characters.json and create a backup. Close Icarus before changing profiles or
characters that it has loaded.

ITEM FEATURES
Select a part or an alteration to read its effect beneath the list. The same
description appears when choosing a replacement. Search by effect to find
bonuses such as melee damage. In Add item, turn on Add-ons only to search the
effects of loose kits and modules. Reopen a loose add-on's Item tab to read
its description. Values describe one selection in the base game.

Item — Set the stack quantity and the current durability in save units.
Parts — Select a legendary weapon slot, choose Edit slot, then search for a
part and set its unlock progress. The selection updates the slot and its
corresponding alteration. Clearing a slot removes one copy of its old effect.
If the target effect already exists, the selector keeps it. Other effects,
including repeated copies, can be edited individually in Alterations.
For a weapon without a catalogued layout, existing part IDs identify their
variants. Use Add saved slot only if you know the missing slot's position.

Attributes — Select Item attributes, Custom stats, World stats or Held world
stats. Choose Add or Edit, search by display name or ID, and enter the signed
integer value as stored by Icarus. Units depend on the stat.

Alterations - Select an inventory row and click Edit alterations. The left
list shows each copy saved on that item. The right list shows 346 catalogued
alterations with their effects. Select a row on either side for the full
description and game ID. Search by name, ID or effect, or tick Attachment
effects only to browse alterations granted by kits.

To add an alteration, select it on the right and click Add to item. To change
one, select its copy on the left and its replacement on the right, then click
Replace selected. For example, replacing Melee_Damage_1 with Melee_Damage_2
changes the listed bonus from +10% to +20% melee damage. Remove selected
removes one copy. Apply stages your edits. Save changes writes the inventory.

Alteration strengths and conditions come from the game's definitions. The
copy count shows how many entries are saved. Icarus determines which effects
apply together. For a legendary part change, use Parts to update the fitted
part and its effect together. For a loose kit or suit module, use Add item.

Properties — Change saved item state, including ammo type, magazine count,
stored fluid or energy, spoil time, variation and other dynamic properties.
Tags — Add, change or remove saved runtime gameplay tags.
Full item JSON — Edit additional or mod-specific fields, including nested
data. Use JSON returns to the item tabs. Keep the original DatabaseGUID.
Prospect-side inventories referenced by a link ID are stored outside this
file. Changing a link ID does not create a physical attachment or its contents.

BACKUPS
Every save creates a timestamped .bak beside MetaInventory.json. Restore
backup replaces the open inventory with a selected backup immediately and
backs up the file it replaces. If a damaged save cannot be opened, close
Icarus and the editor, keep a copy of the damaged file, and copy a known-good
backup over MetaInventory.json in the same folder.

IN-GAME SCOPE
This tool edits the player's station inventory on disk. Items already deployed
on a prospect live in separate records. Adding an item here creates a new
instance. It does not transfer the original out of a pod or prospect.
The game controls which items it accepts for loadout and orbital return.
An ordinary planet item written to the file may be filtered or lost in game.
The base station inventory has 200 slots. Check your available space before
adding items. Server-specific item definitions and later patches can differ.

File-level tests used copies of a 42-entry station inventory and a 35-pet save.
Module exports and saved pet edits were checked on disk. The game determines
which combinations take effect and which cargo survives orbital transfer.
