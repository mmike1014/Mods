ORBITAL EXCHANGE EDITOR
Windows desktop edition 1.5

GET STARTED
1. Extract the whole ZIP to a folder on your PC. Keep the EXE and DLL together.
2. Run OrbitalExchangeEditor.exe. It opens your station inventory automatically
   when it finds one player profile. Use Open inventory to choose a different
   profile or to work on a copy.

The usual file is
%LOCALAPPDATA%\Icarus\Saved\PlayerData\<SteamID>\MetaInventory.json

EDIT YOUR INVENTORY
Select any inventory row to read its description and current stats in the
right-hand pane. Scroll for custom attributes, equipped parts, alterations
and base item stats. The Item tab updates as you edit. Add item shows the
starting values for a new copy and the quantity you have chosen.

Current item values come from the selected save entry. Base item stats use
the game's item definitions. The displayed bonuses retain their individual
sources. Combat totals depend on the character, ammunition, target and
conditions in game. Custom rows can show saved properties even when their
base definition is unavailable. Twenty catalog rows without authored text
have short descriptions based on their item names and game-data tags.

Use Add item to search by display name or game ID and pick a stack quantity.
The initial list shows items tagged for orbit. Include planet items also shows
ordinary materials, crafted equipment and other entries from the base game.
New items receive their own instance ID and available base template properties.
The catalog contains 3,040 item rows from Steam client build 26636089.
Stack limits and initial durability come from that build's base tables.

Choose Add-ons only to browse loose attachment kits and suit modules. To add
a modded item, enter its exact row name in Search and choose Add by game ID.
The corresponding game or mod must define that item for Icarus to load it.

Double-click an inventory row to edit it. Apply stages all changes to that item.
Cancel discards them. Save changes in the main window writes them to disk.

SAVING WHILE ICARUS IS RUNNING
Save changes works while Icarus is open. The editor combines your edits with
changes to other entries already saved on disk. If both versions changed the
same item, the editor reports the conflict and keeps your edits open. If Icarus
briefly locks the file, the editor retries. Retry Save changes if the file
remains busy.

Icarus may keep its own copy of the inventory in memory. If the Workshop
still shows older items after you save, reload Icarus. A later in-game save
can overwrite edits made on disk. The editor's status reflects the disk save.

ITEM FEATURES
Select a part or an alteration to read its effect beneath the list. The same
description appears when choosing a replacement. Search by effect to find
bonuses such as melee damage. In Add item, turn on Add-ons only to search the
effects of loose kits and modules. Reopen a loose add-on's Item tab to read
its description. Values describe one selection in the base game.

Item — Set the stack quantity and the current durability in save units.
Parts — Select a legendary weapon slot, choose Edit slot, then search for a
part and set its unlock progress. The selection updates the slot and its
corresponding alteration. Clearing a slot removes one copy of its old effect.
If the target effect already exists, the selector keeps it. Other effects,
including repeated copies, can be edited individually in Alterations.
For a weapon without a catalogued layout, existing part IDs identify their
variants. Use Add saved slot only if you know the missing slot's position.

Attributes — Select Item attributes, Custom stats, World stats or Held world
stats. Choose Add or Edit, search by display name or ID, and enter the signed
integer value as stored by Icarus. Units depend on the stat.

Alterations - Select an inventory row and click Edit alterations. The left
list shows each copy saved on that item. The right list shows 346 catalogued
alterations with their effects. Select a row on either side for the full
description and game ID. Search by name, ID or effect, or tick Attachment
effects only to browse alterations granted by kits.

To add an alteration, select it on the right and click Add to item. To change
one, select its copy on the left and its replacement on the right, then click
Replace selected. For example, replacing Melee_Damage_1 with Melee_Damage_2
changes the listed bonus from +10% to +20% melee damage. Remove selected
removes one copy. Apply stages your edits. Save changes writes the inventory.

Alteration strengths and conditions come from the game's definitions. The
copy count shows how many entries are saved. Icarus determines which effects
apply together. For a legendary part change, use Parts to update the fitted
part and its effect together. For a loose kit or suit module, use Add item.

Properties — Change saved item state, including ammo type, magazine count,
stored fluid or energy, spoil time, variation and other dynamic properties.
Tags — Add, change or remove saved runtime gameplay tags.
Full item JSON — Edit additional or mod-specific fields, including nested
data. Use JSON returns to the item tabs. Keep the original DatabaseGUID.
Prospect-side inventories referenced by a link ID are stored outside this
file. Changing a link ID does not create a physical attachment or its contents.

BACKUPS
Every save creates a timestamped .bak beside MetaInventory.json. Restore
backup replaces the open inventory with a selected backup immediately and
backs up the file it replaces. If a damaged save cannot be opened, close
Icarus and the editor, keep a copy of the damaged file, and copy a known-good
backup over MetaInventory.json in the same folder.

IN-GAME SCOPE
This tool edits the player's station inventory on disk. Items already deployed
on a prospect live in separate records. Adding an item here creates a new
instance. It does not transfer the original out of a pod or prospect.
The game controls which items it accepts for loadout and orbital return.
An ordinary planet item written to the file may be filtered or lost in game.
The base station inventory has 200 slots. Check your available space before
adding items. Server-specific item definitions and later patches can differ.

File-level tests used a copy of a 39-entry Icarus station inventory, including
legendary equipment. The game determines which combinations take effect and
which cargo survives orbital transfer.
